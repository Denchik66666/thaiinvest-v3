"use client";

import { useState, useMemo } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useRouter } from "next/navigation";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Text } from "@/components/ui/Text";
import { Container } from "@/components/ui/Container";
import { apiClient } from "@/lib/api-client";
import { formatCurrency, cn } from "@/lib/utils";

import { InvestorsTable } from "@/components/investors/InvestorsTable";
import { CreateInvestorModal } from "@/components/investors/CreateInvestorModal";

/* ============================================================
   ФУНКЦИЯ РАСЧЁТА ТЕКУЩЕЙ НЕДЕЛИ (UI)
============================================================ */
function getCurrentWeek() {
  const today = new Date();
  const dayOfWeek = today.getDay();
  const monday = new Date(today);
  monday.setDate(today.getDate() - (dayOfWeek === 0 ? 6 : dayOfWeek - 1));
  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);
  const nextMonday = new Date(monday);
  nextMonday.setDate(monday.getDate() + 7);

  const format = (date: Date) => {
    const days = ["ВС", "ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ"];
    const d = date.getDate().toString().padStart(2, "0");
    const m = (date.getMonth() + 1).toString().padStart(2, "0");
    return `${days[date.getDay()]} ${d}.${m}`;
  };

  return { start: format(monday), end: format(sunday), nextPayout: format(nextMonday) };
}

type InvestorRow = {
  id: number;
  name: string;
  body: number;
  rate: number;
  accrued: number;
  paid: number;
  due: number;
  status: string;
  isPrivate: boolean;
  owner: {
    username: string;
    role: string;
  };
};

type WeeklyLedgerRow = {
  weekStart: string;
  weekEnd: string;
  bodyStart: number;
  weeklyRatePercent: number;
  accruedAdded: number;
  interestPaid: number;
  bodyPaid: number;
  closingPaid: number;
  accruedEnd: number;
  bodyEnd: number;
};

type WeeklyLedgerResponse = {
  investor: {
    id: number;
    name: string;
    rate: number;
  };
  summary: {
    weeks: number;
    totalAccruedAdded: number;
    totalInterestPaid: number;
    totalBodyPaid: number;
  };
  note: string;
  rows: WeeklyLedgerRow[];
};

export default function DashboardPage() {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();
  const queryClient = useQueryClient();

  const [networkFilter, setNetworkFilter] = useState<"common" | "private" | "all">("common");
  const [showModal, setShowModal] = useState(false);
  const [selectedInvestorId, setSelectedInvestorId] = useState<number | null>(null);

  const [formData, setFormData] = useState({
    name: "",
    handle: "",
    phone: "",
    body: "",
    rate: "",
    entryDate: new Date().toISOString().split("T")[0],
    isPrivate: false,
  });

  // Загрузка данных инвесторов
  const { data: investorsData, isLoading: loadingInvestors } = useQuery({
    queryKey: ["investors", networkFilter],
    queryFn: () => apiClient.get<{ investors: InvestorRow[] }>(`/api/investors?network=${networkFilter}`),
    enabled: !!user,
  });

  const investors = useMemo(() => investorsData?.investors ?? [], [investorsData]);
  const selectedInvestor = useMemo(
    () => investors.find((inv) => inv.id === selectedInvestorId) ?? null,
    [investors, selectedInvestorId]
  );

  const { data: ledgerData, isLoading: loadingLedger } = useQuery({
    queryKey: ["weekly-ledger", selectedInvestorId],
    queryFn: () => apiClient.get<WeeklyLedgerResponse>(`/api/investors/${selectedInvestorId}/weekly-ledger`),
    enabled: !!selectedInvestorId && !!user,
  });

  // Мутация создания инвестора
  const createMutation = useMutation({
    mutationFn: (data: typeof formData) => apiClient.post("/api/investors", data),
    onSuccess: () => {
      setShowModal(false);
      setFormData({
        name: "",
        handle: "",
        phone: "",
        body: "",
        rate: "",
        entryDate: new Date().toISOString().split("T")[0],
        isPrivate: false,
      });
      queryClient.invalidateQueries({ queryKey: ["investors"] });
    },
    onError: (error: unknown) => {
      // Ошибка будет отображаться в модальном окне
      console.error("Create investor error:", error);
    },
  });

  // Финансовая статистика
  const stats = useMemo(() => {
    return investors.reduce(
      (acc, inv) => ({
        aum: acc.aum + (inv.body || 0),
        paid: acc.paid + (inv.paid || 0),
        due: acc.due + (inv.due || 0),
      }),
      { aum: 0, paid: 0, due: 0 }
    );
  }, [investors]);

  const currentWeek = getCurrentWeek();

  if (authLoading) return <div className="flex items-center justify-center min-h-screen"><Text>Загрузка...</Text></div>;
  if (!user) { router.push("/login"); return null; }

  const isSuperAdmin = user.role === "SUPER_ADMIN";

  return (
    <Container>
      <div className="min-h-screen p-4 md:p-8 space-y-6">
        {/* HEADER */}
        <Card className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">ThaiInvest Dashboard</h1>
            <Text className="text-muted-foreground">
              {user.username} • <span className="font-medium text-primary">{user.role}</span>
            </Text>
          </div>
          <Button onClick={() => apiClient.post("/api/auth/logout", {}).then(() => window.location.href = "/login")} variant="outline">
            Выйти
          </Button>
        </Card>

        {/* СЕТИ */}
        {isSuperAdmin && (
          <div className="flex gap-2">
            {(["common", "private", "all"] as const).map((f) => (
              <Button
                key={f}
                onClick={() => setNetworkFilter(f)}
                variant={networkFilter === f ? "primary" : "outline"}
                size="sm"
                className="capitalize"
              >
                {f === "common" ? "Общая" : f === "private" ? "Личная" : "Все"}
              </Button>
            ))}
          </div>
        )}

        {/* СТАТИСТИКА */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <StatCard title="Общее тело" value={stats.aum} color="text-blue-600" />
          <StatCard title="Выплачено" value={stats.paid} color="text-green-600" />
          <StatCard title="К выплате" value={stats.due} color="text-orange-600" />
        </div>

        {/* РАСЧЁТНЫЙ ЦИКЛ */}
        <Card className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <StatItem label="Текущий цикл" value={`${currentWeek.start} — ${currentWeek.end}`} />
          <StatItem label="Следующая выплата" value={currentWeek.nextPayout} highlight />
        </Card>

        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold">Список инвесторов</h2>
          <Button onClick={() => setShowModal(true)}>+ Создать инвестора</Button>
        </div>

        {loadingInvestors ? (
          <div className="py-12 text-center text-muted-foreground">Загрузка данных...</div>
        ) : (
          <InvestorsTable investors={investors} onOpenLedger={setSelectedInvestorId} />
        )}

        {selectedInvestor && (
          <Card className="p-0 overflow-hidden">
            <div className="p-4 border-b border-border flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold">Недельный расчет: {selectedInvestor.name}</h3>
                <Text className="text-xs">{ledgerData?.note ?? "Расчет по закрытым неделям"}</Text>
              </div>
              <Button size="sm" variant="outline" onClick={() => setSelectedInvestorId(null)}>
                Скрыть
              </Button>
            </div>

            {loadingLedger ? (
              <div className="p-6 text-sm text-muted-foreground">Считаем недели...</div>
            ) : !ledgerData ? (
              <div className="p-6 text-sm text-muted-foreground">Нет данных для расчета.</div>
            ) : (
              <>
                <div className="p-4 grid grid-cols-1 md:grid-cols-3 gap-3 border-b border-border bg-muted/20">
                  <Text>Недель: <span className="font-semibold text-foreground">{ledgerData.summary.weeks}</span></Text>
                  <Text>Начислено: <span className="font-semibold text-blue-600">{formatCurrency(ledgerData.summary.totalAccruedAdded)}</span></Text>
                  <Text>Выплачено %: <span className="font-semibold text-green-600">{formatCurrency(ledgerData.summary.totalInterestPaid)}</span></Text>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-muted/40 border-b border-border">
                        <th className="text-left px-3 py-2">Неделя</th>
                        <th className="text-right px-3 py-2">Тело</th>
                        <th className="text-right px-3 py-2">Ставка/нед</th>
                        <th className="text-right px-3 py-2">Начислено</th>
                        <th className="text-right px-3 py-2">Выплата %</th>
                        <th className="text-right px-3 py-2">Остаток %</th>
                      </tr>
                    </thead>
                    <tbody>
                      {ledgerData.rows.map((row) => (
                        <tr key={row.weekStart} className="border-b border-border/60">
                          <td className="px-3 py-2">
                            {new Date(row.weekStart).toLocaleDateString("ru-RU")} -{" "}
                            {new Date(row.weekEnd).toLocaleDateString("ru-RU")}
                          </td>
                          <td className="px-3 py-2 text-right">{formatCurrency(row.bodyStart)}</td>
                          <td className="px-3 py-2 text-right">{row.weeklyRatePercent.toFixed(2)}%</td>
                          <td className="px-3 py-2 text-right text-blue-600">{formatCurrency(row.accruedAdded)}</td>
                          <td className="px-3 py-2 text-right text-green-600">{formatCurrency(row.interestPaid)}</td>
                          <td className="px-3 py-2 text-right text-orange-600">{formatCurrency(row.accruedEnd)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </>
            )}
          </Card>
        )}

        <CreateInvestorModal
          open={showModal}
          onClose={() => setShowModal(false)}
          onSubmit={() => createMutation.mutate(formData)}
          formData={formData}
          setFormData={setFormData}
          userRole={user.role}
          loading={createMutation.isPending}
          error={createMutation.error instanceof Error ? createMutation.error.message : undefined}
        />
      </div>
    </Container>
  );
}

function StatCard({ title, value, color }: { title: string; value: number; color: string }) {
  return (
    <Card className="p-6">
      <Text className="text-sm font-medium text-muted-foreground mb-1">{title}</Text>
      <div className={cn("text-3xl font-bold", color)}>{formatCurrency(value)}</div>
    </Card>
  );
}

function StatItem({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div className="space-y-1">
      <Text className="text-sm font-medium text-muted-foreground">{label}</Text>
      <Text className={cn("text-lg font-semibold", highlight && "text-green-600")}>{value}</Text>
    </div>
  );
}
