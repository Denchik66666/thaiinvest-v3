import { cn } from "@/lib/utils";

export type CardProps = React.HTMLAttributes<HTMLDivElement>;

export function Card({ className, ...props }: CardProps) {
  return (
    <div
      className={cn(
        "bg-card border border-border rounded-xl shadow-sm p-6",
        className
      )}
      {...props}
    />
  );
}