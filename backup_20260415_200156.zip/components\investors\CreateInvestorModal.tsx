"use client";

import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Label } from "@/components/ui/Label";
import { Text } from "@/components/ui/Text";
import { FormGroup } from "@/components/ui/FormGroup";
import { cn } from "@/lib/utils";

export interface InvestorForm {
  name: string;
  handle: string;
  phone: string;
  body: string;
  rate: string;
  entryDate: string;
  isPrivate: boolean;
}

interface ModalProps {
  open: boolean;
  onClose: () => void;
  onSubmit: () => void;
  formData: InvestorForm;
  setFormData: (data: InvestorForm) => void;
  userRole?: string;
  loading?: boolean;
  error?: string;
}

export function CreateInvestorModal({
  open,
  onClose,
  onSubmit,
  formData,
  setFormData,
  userRole,
  loading,
  error,
}: ModalProps) {

  if (!open) return null;

  const showNetworkSwitcher = userRole === "SUPER_ADMIN";

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 px-4 backdrop-blur-sm animate-in fade-in duration-200">
      <Card className="w-full max-w-md bg-card border border-border p-6 space-y-5 shadow-2xl animate-in zoom-in-95 duration-200">

        {/* Заголовок */}
        <h2 className="text-xl font-bold text-foreground">
          Создать инвестора
        </h2>

        {/* ✅ Переключатель сетей (только SUPER_ADMIN) */}
        {showNetworkSwitcher && (
          <div className="space-y-2">
            <Label className="text-sm font-semibold">Сеть</Label>

            <div className="flex gap-2 p-1 bg-muted rounded-lg">
              <button
                type="button"
                disabled={loading}
                onClick={() =>
                  setFormData({ ...formData, isPrivate: false })
                }
                className={cn(
                  "flex-1 px-4 py-2 text-sm font-medium rounded-md transition-all",
                  !formData.isPrivate
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground disabled:opacity-50"
                )}
              >
                Общая сеть
              </button>

              <button
                type="button"
                disabled={loading}
                onClick={() =>
                  setFormData({ ...formData, isPrivate: true })
                }
                className={cn(
                  "flex-1 px-4 py-2 text-sm font-medium rounded-md transition-all",
                  formData.isPrivate
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground disabled:opacity-50"
                )}
              >
                Личная сеть
              </button>
            </div>

            <Text className="text-xs text-muted-foreground">
              {!formData.isPrivate
                ? "Инвестор виден Семёну (общая сеть)"
                : "Инвестор скрыт. Видишь только ты (личная сеть)"}
            </Text>
          </div>
        )}

        <form
          onSubmit={(e) => {
            e.preventDefault();
            onSubmit();
          }}
          className="space-y-4"
        >
          {/* Имя */}
          <FormGroup>
            <Label>Имя *</Label>
            <Input
              required
              disabled={loading}
              value={formData.name}
              onChange={(e) =>
                setFormData({ ...formData, name: e.target.value })
              }
              placeholder="Имя инвестора"
            />
          </FormGroup>

          <div className="grid grid-cols-2 gap-4">
            {/* Telegram */}
            <FormGroup>
              <Label>Telegram</Label>
              <Input
                disabled={loading}
                value={formData.handle}
                onChange={(e) =>
                  setFormData({ ...formData, handle: e.target.value })
                }
                placeholder="@username"
              />
            </FormGroup>

            {/* Телефон */}
            <FormGroup>
              <Label>Телефон</Label>
              <Input
                disabled={loading}
                value={formData.phone}
                onChange={(e) =>
                  setFormData({ ...formData, phone: e.target.value })
                }
                placeholder="+66..."
              />
            </FormGroup>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {/* Тело */}
            <FormGroup>
              <Label>Тело (бат) *</Label>
              <Input
                type="number"
                required
                disabled={loading}
                value={formData.body}
                onChange={(e) =>
                  setFormData({ ...formData, body: e.target.value })
                }
                placeholder="100000"
              />
            </FormGroup>

            {/* Ставка или авто-поле */}
            <FormGroup>
              <Label>Ставка (%) *</Label>
              {formData.isPrivate ? (
                <Input
                  disabled
                  value="Авто (50%)"
                  className="opacity-70 cursor-not-allowed bg-muted"
                />
              ) : (
                <Input
                  type="number"
                  required
                  disabled={loading}
                  value={formData.rate}
                  onChange={(e) =>
                    setFormData({ ...formData, rate: e.target.value })
                  }
                  placeholder="10"
                />
              )}
            </FormGroup>
          </div>

          {/* Дата входа */}
          <FormGroup>
            <Label>Дата входа *</Label>
            <Input
              type="date"
              required
              disabled={loading}
              value={formData.entryDate}
              onChange={(e) =>
                setFormData({ ...formData, entryDate: e.target.value })
              }
            />
          </FormGroup>

          {/* ОТОБРАЖЕНИЕ ОШИБКИ */}
          {error && (
            <div className="p-3 text-xs font-medium text-red-500 bg-red-500/10 border border-red-500/20 rounded-md animate-in fade-in slide-in-from-top-1">
              {error}
            </div>
          )}

          {/* Кнопки */}
          <div className="flex justify-between gap-3 pt-2">
            <Button 
              variant="outline" 
              type="button" 
              onClick={onClose} 
              disabled={loading}
              className="flex-1"
            >
              Отмена
            </Button>
            <Button 
              type="submit" 
              disabled={loading}
              className="flex-1"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                  Создание...
                </span>
              ) : (
                "Создать"
              )}
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
