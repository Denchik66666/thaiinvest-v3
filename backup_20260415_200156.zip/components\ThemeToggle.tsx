"use client";

import { useEffect, useState } from "react";

// Иконка (минималистичная монохромная)
function IconSunMoon() {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 24 24"
      stroke="currentColor"
      fill="none"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      className="text-foreground"
    >
      <circle cx="12" cy="12" r="4" />
      <path d="M12 2v2" />
      <path d="M12 20v2" />
      <path d="M4.93 4.93l1.41 1.41" />
      <path d="M17.66 17.66l1.41 1.41" />
      <path d="M2 12h2" />
      <path d="M20 12h2" />
      <path d="M4.93 19.07l1.41-1.41" />
      <path d="M17.66 6.34l1.41-1.41" />
    </svg>
  );
}

// Иконка мини-меню
function IconPalette() {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 24 24"
      stroke="currentColor"
      fill="none"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      className="text-foreground"
    >
      <path d="M12 3a9 9 0 0 0-9 9 9 9 0 0 0 9 9h1a3 3 0 0 0 0-6h-2a3 3 0 0 1-3-3 3 3 0 0 1 3-3h5a3 3 0 0 0 0-6h-4z" />
    </svg>
  );
}

export default function ThemeToggle() {
  const [open, setOpen] = useState(false);
  const [currentTheme, setCurrentTheme] = useState(() => {
    if (typeof window === "undefined") return "theme-linear";
    return localStorage.getItem("app-theme") ?? "theme-linear";
  });
  const [dark, setDark] = useState(() => {
    if (typeof window === "undefined") return false;
    return localStorage.getItem("app-dark-mode") === "true";
  });

  useEffect(() => {
    document.documentElement.classList.remove(
      "theme-linear",
      "theme-vercel",
      "theme-shadcn"
    );
    document.documentElement.classList.add(currentTheme);
    document.documentElement.classList.toggle("dark", dark);
    localStorage.setItem("app-theme", currentTheme);
    localStorage.setItem("app-dark-mode", String(dark));
  }, [currentTheme, dark]);

  // Переключение основной темы
  const applyTheme = (theme: string) => {
    setCurrentTheme(theme);
    setOpen(false);
  };

  // Light / Dark
  const toggleDark = () => {
    const next = !dark;
    setDark(next);
  };

  return (
    <div className="relative inline-block text-left">
      {/* Кнопка открытия */}
      <button
        onClick={() => setOpen(!open)}
        className="
          p-2 rounded-md border border-border
          hover:bg-secondary transition
          flex items-center gap-2
        "
      >
        <IconPalette />
      </button>

      {/* Выпадающее меню */}
      {open && (
        <div
          className="
            absolute right-0 mt-2 w-48 
            rounded-md border border-border 
            bg-background shadow-lg p-2 z-20
          "
        >
          {/* Смена темы */}
          <div className="space-y-1">
            <button
              onClick={() => applyTheme("theme-linear")}
              className={`
                block w-full text-left px-3 py-2 rounded 
                hover:bg-secondary transition
                ${currentTheme === "theme-linear" ? "bg-secondary" : ""}
              `}
            >
              Linear (Default)
            </button>

            <button
              onClick={() => applyTheme("theme-vercel")}
              className={`
                block w-full text-left px-3 py-2 rounded 
                hover:bg-secondary transition
                ${currentTheme === "theme-vercel" ? "bg-secondary" : ""}
              `}
            >
              Vercel Style
            </button>

            <button
              onClick={() => applyTheme("theme-shadcn")}
              className={`
                block w-full text-left px-3 py-2 rounded 
                hover:bg-secondary transition
                ${currentTheme === "theme-shadcn" ? "bg-secondary" : ""}
              `}
            >
              Shadcn UI
            </button>
          </div>

          {/* Разделитель */}
          <div className="my-2 border-t border-border"></div>

          {/* Light / Dark */}
          <button
            onClick={toggleDark}
            className="
              flex items-center gap-2 px-3 py-2 rounded 
              hover:bg-secondary transition w-full
            "
          >
            <IconSunMoon />
            Mode
          </button>
        </div>
      )}
    </div>
  );
}