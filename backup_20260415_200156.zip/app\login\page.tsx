"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

import { Card } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import PasswordInput from "@/components/ui/PasswordInput";
import { Button } from "@/components/ui/Button";
import { Label } from "@/components/ui/Label";
import { Text } from "@/components/ui/Text";
import { FormGroup } from "@/components/ui/FormGroup";

export default function LoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const router = useRouter();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Ошибка входа");
        setLoading(false);
        return;
      }

      router.push("/dashboard");
    } catch {
      setError("Ошибка подключения к серверу");
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <Card className="w-full max-w-sm p-6 space-y-6">
        <div className="text-center space-y-2">
          <div className="mx-auto w-10 h-10 rounded bg-primary flex items-center justify-center text-primary-foreground font-bold">
            T
          </div>

          <Text>ThaiInvest v3.0</Text>

          <Text>
            Система управления инвестициями
          </Text>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <FormGroup>
            <Label>Логин</Label>
            <Input
              placeholder="Введите логин"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              autoCapitalize="none"
              autoCorrect="off"
              autoComplete="username"
              required
            />
          </FormGroup>

          <FormGroup>
            <Label>Пароль</Label>
            <PasswordInput
              placeholder="Введите пароль"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoCapitalize="none"
              autoCorrect="off"
              autoComplete="current-password"
              required
            />
          </FormGroup>

          {error && (
            <Text className="text-red-500">
              {error}
            </Text>
          )}

          <Button className="w-full" disabled={loading}>
            {loading ? "Вход..." : "Войти"}
          </Button>
        </form>

        <Text className="text-center text-xs opacity-60">
          © 2026 ThaiInvest. Все права защищены.
        </Text>
      </Card>
    </div>
  );
}