'use client'

import { useState } from 'react'

function getInitialDarkMode() {
  if (typeof window === 'undefined') {
    return false
  }

  return localStorage.getItem('theme') === 'dark'
}

export function useTheme() {
  const [darkMode, setDarkMode] = useState(getInitialDarkMode)

  // Переключение темы
  const toggleTheme = () => {
    const newDarkMode = !darkMode
    setDarkMode(newDarkMode)
    localStorage.setItem('theme', newDarkMode ? 'dark' : 'light')
    document.documentElement.classList.toggle('dark', newDarkMode)
  }

  return { darkMode, toggleTheme }
}