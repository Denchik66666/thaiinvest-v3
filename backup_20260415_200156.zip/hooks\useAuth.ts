'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'

interface User {
  id: number
  username: string
  role: string
  isSystemOwner: boolean
}

export function useAuth() {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    let isMounted = true
    const controller = new AbortController()
    const timeoutId = window.setTimeout(() => controller.abort(), 4500)

    const run = async () => {
      try {
        const res = await fetch('/api/auth/me', { cache: 'no-store', signal: controller.signal })
        if (!res.ok) {
          throw new Error('UNAUTHORIZED')
        }

        const data = await res.json()
        if (!isMounted) return
        setUser(data.user)
        setLoading(false)
      } catch {
        if (!isMounted) return
        setUser(null)
        setLoading(false)
        router.replace('/login')
        setTimeout(() => {
          if (window.location.pathname !== '/login') {
            window.location.href = '/login'
          }
        }, 120)
      }
    }

    run()

    return () => {
      isMounted = false
      clearTimeout(timeoutId)
      controller.abort()
    }
  }, [router])

  return { user, loading }
}