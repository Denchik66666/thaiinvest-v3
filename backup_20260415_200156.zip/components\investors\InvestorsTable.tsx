"use client";

import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { formatCurrency, cn } from "@/lib/utils";

interface Investor {
  id: number;
  name: string;
  body: number;
  rate: number;
  accrued: number;
  paid: number;
  due: number;
  status: string;
  isPrivate: boolean;
  owner: {
    username: string;
    role: string;
  };
}

/* ---------------------------------------------------------
   БЕЙДЖ СТАТУСА
--------------------------------------------------------- */
export function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    active: "bg-green-500/10 text-green-600 border-green-200 dark:border-green-900",
    awaiting_activation: "bg-yellow-500/10 text-yellow-600 border-yellow-200 dark:border-yellow-900",
    paused: "bg-blue-500/10 text-blue-600 border-blue-200 dark:border-blue-900",
    closed: "bg-red-500/10 text-red-600 border-red-200 dark:border-red-900",
  };

  const labels: Record<string, string> = {
    active: "Активен",
    awaiting_activation: "Ожидает",
    paused: "Пауза",
    closed: "Закрыт",
  };

  return (
    <span className={cn("px-2 py-0.5 text-xs font-medium rounded-full border", styles[status] || "bg-gray-100 text-gray-600")}>
      {labels[status] || status}
    </span>
  );
}

/* ---------------------------------------------------------
   ТАБЛИЦА ИНВЕСТОРОВ
--------------------------------------------------------- */
export function InvestorsTable({
  investors,
  onOpenLedger,
}: {
  investors: Investor[];
  onOpenLedger?: (investorId: number) => void;
}) {
  if (investors.length === 0) {
    return (
      <Card className="flex items-center justify-center py-12 text-muted-foreground border-dashed">
        Пока нет инвесторов.
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden p-0 border-none shadow-md">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-muted/50 border-b border-border">
              <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Имя</th>
              <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-right">Тело</th>
              <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-center">Ставка</th>
              <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-right">Начислено</th>
              <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-right text-green-600">Выплачено</th>
              <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-right text-orange-600">К выплате</th>
              <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-center">Статус</th>
              <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-center">Сеть</th>
              <th className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-center">Расчет</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border bg-card">
            {investors.map((inv) => (
              <tr key={inv.id} className="hover:bg-muted/30 transition-colors group">
                <td className="px-4 py-4">
                  <div className="font-semibold text-foreground">{inv.name}</div>
                  <div className="text-xs text-muted-foreground">{inv.owner.username}</div>
                </td>
                <td className="px-4 py-4 text-right font-medium">{formatCurrency(inv.body)}</td>
                <td className="px-4 py-4 text-center">
                  <span className="text-sm font-medium">{inv.rate}%</span>
                </td>
                <td className="px-4 py-4 text-right font-medium text-blue-600">{formatCurrency(inv.accrued)}</td>
                <td className="px-4 py-4 text-right font-medium text-green-600">{formatCurrency(inv.paid)}</td>
                <td className="px-4 py-4 text-right font-medium text-orange-600">{formatCurrency(inv.due)}</td>
                <td className="px-4 py-4 text-center">
                  <StatusBadge status={inv.status} />
                </td>
                <td className="px-4 py-4 text-center">
                  {inv.isPrivate ? (
                    <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400">Личная</span>
                  ) : (
                    <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-400">Общая</span>
                  )}
                </td>
                <td className="px-4 py-4 text-center">
                  <Button size="sm" variant="outline" onClick={() => onOpenLedger?.(inv.id)}>
                    Расчет
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}
