import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { verifyToken } from '@/lib/auth'
import { cookies } from 'next/headers'
import { CreateInvestorSchema } from '@/lib/schemas'
import { logAction } from '@/lib/audit'
import { countFullWeeksBetween, getNextMonday, getPreviousOrCurrentMonday } from '@/lib/weekly'
import { getCurrentBusinessRate } from '@/lib/business-rate'

/* ================================
   ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
================================ */

// ретро‑расчёт процентов
function calculateAccrued(body: number, rate: number, weeks: number): number {
  const weeklyRate = (rate / 100) / 4     // упрощенно: месячная ÷ 4
  return body * weeklyRate * weeks
}

/* ================================
            GET инвесторы
=============================== */

export async function GET(request: NextRequest) {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get('token')?.value

    if (!token) {
      return NextResponse.json({ error: 'Не авторизован' }, { status: 401 })
    }

    const decoded = verifyToken(token)
    if (!decoded) {
      return NextResponse.json({ error: 'Неверный токен' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const network = searchParams.get('network') ?? 'all'

    let whereClause: { isPrivate?: boolean } = {}

    // OWNER видит только общую сеть
    if (decoded.role === 'OWNER') {
      whereClause = { isPrivate: false }
    }

    // SUPER_ADMIN видит всё, но может переключать фильтр
    if (decoded.role === 'SUPER_ADMIN') {
      if (network === 'common') whereClause = { isPrivate: false }
      else if (network === 'private') whereClause = { isPrivate: true }
    }

    const investors = await prisma.investor.findMany({
      where: whereClause,
      include: {
        owner: {
          select: {
            id: true,
            username: true,
            role: true,
          },
        },
        payments: true,
      },
      orderBy: { createdAt: 'desc' },
    })

    const result = investors.map((inv) => {
      const paid = inv.payments.reduce((sum, p) => sum + p.amount, 0)
      const interestPaid = inv.payments
        .filter((p) => p.type === 'interest')
        .reduce((sum, p) => sum + p.amount, 0)
      
      const due = Math.max(inv.accrued - interestPaid, 0)

      return {
        ...inv,
        paid,
        due,
      }
    })

    return NextResponse.json({ investors: result })
  } catch (error) {
    console.error('Get investors error:', error)
    return NextResponse.json({ error: 'Ошибка сервера' }, { status: 500 })
  }
}

/* ================================
          POST СОЗДАНИЕ
================================ */

export async function POST(request: NextRequest) {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get('token')?.value

    if (!token) {
      return NextResponse.json({ error: 'Не авторизован' }, { status: 401 })
    }

    const decoded = verifyToken(token)
    if (!decoded) {
      return NextResponse.json({ error: 'Неверный токен' }, { status: 401 })
    }

    // 1. Валидация Zod
    const bodyResult = CreateInvestorSchema.safeParse(await request.json())
    if (!bodyResult.success) {
      return NextResponse.json({ error: bodyResult.error.issues[0]?.message ?? 'Некорректные данные' }, { status: 400 })
    }

    const { 
      name, 
      handle, 
      phone, 
      body: investorBody, 
      rate, 
      entryDate, 
      isPrivate 
    } = bodyResult.data

    const isPrivateNetwork = Boolean(isPrivate)
    const entry = new Date(entryDate)

    const today = new Date()
    today.setHours(0, 0, 0, 0)

    const activationDate = getNextMonday(entry)
    const status = activationDate <= today ? 'active' : 'awaiting_activation'

    /* ================================
          Проверка лимита Личной Сети
    ================================= */

    if (decoded.role === 'SUPER_ADMIN' && isPrivateNetwork) {
      const adminMainInvestor = await prisma.investor.findFirst({
        where: { ownerId: decoded.userId, isPrivate: false }
      })

      if (!adminMainInvestor) {
        return NextResponse.json(
          { error: 'Сначала создайте базового инвестора SUPER_ADMIN в общей сети, затем личную сеть' },
          { status: 400 }
        )
      }

      const adminBody = adminMainInvestor.body
      const privateSum = await prisma.investor.aggregate({
        _sum: { body: true },
        where: { ownerId: decoded.userId, isPrivate: true }
      })

      const currentPrivateTotal = privateSum._sum.body ?? 0
      if (currentPrivateTotal + investorBody > adminBody) {
        return NextResponse.json({ error: 'Лимит личной сети превышен' }, { status: 400 })
      }
    }

    /* ================================
           СТАВКА
    ================================= */
    
    let finalRate = rate

    if (decoded.role === 'SUPER_ADMIN' && isPrivateNetwork) {
      const businessRate = await getCurrentBusinessRate(today)
      if (!businessRate) {
        return NextResponse.json(
          { error: 'Сначала установите бизнес-ставку OWNER в системе (через /api/system/business-rate)' },
          { status: 400 }
        )
      }

      finalRate = businessRate.rate / 2
    }

    /* ================================
           РЕТРО-РАСЧЁТ ПРОЦЕНТОВ
    ================================= */

    let accrued = 0
    if (status === 'active') {
      const currentWeekMonday = getPreviousOrCurrentMonday(today)
      const weeks = countFullWeeksBetween(activationDate, currentWeekMonday)
      if (weeks > 0) {
        accrued = calculateAccrued(investorBody, finalRate, weeks)
      }
    }

    /* ================================
           СОЗДАЁМ ИНВЕСТОРА
    ================================= */

    const investor = await prisma.investor.create({
      data: {
        ownerId: decoded.userId,
        name,
        handle: handle ?? null,
        phone: phone ?? null,
        body: investorBody,
        rate: finalRate,
        accrued: accrued,
        entryDate: entry,
        activationDate: activationDate,
        status: status,
        isPrivate: isPrivateNetwork,
      },
    })

    // Логируем действие
    await logAction({
      userId: decoded.userId,
      action: 'CREATE_INVESTOR',
      entityType: 'Investor',
      entityId: investor.id,
      newValue: JSON.stringify(investor)
    })

    return NextResponse.json({ success: true, investor })
  } catch (error) {
    console.error('Create investor error:', error)
    return NextResponse.json({ error: 'Ошибка сервера' }, { status: 500 })
  }
}
